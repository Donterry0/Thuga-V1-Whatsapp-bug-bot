THANKS TO:
1. 𝕋𝕙𝕦𝕘𝕒 https://whatsapp.com/channel/0029VauSIRL11ulJqMBK8i19
2. 𝗕𝘂𝘆𝗲𝗿